# Ajedrez Online - Proyecto SaaS

Proyecto universitario de ajedrez online desarrollado con React, Vite y Node.js.

## 🚀 Requisitos previos

- Node.js (v18 o superior)
- npm (viene con Node.js)
- Git

## 📦 Instalación

1. Clona el repositorio
2. Navega a la carpeta del proyecto:
```bash
   cd ajedrez-online
```
3. Instala las dependencias:
```bash
   npm install
```

## 🎮 Ejecutar el proyecto

Para iniciar el servidor de desarrollo:
```bash
npm run dev
```

El proyecto estará disponible en: http://localhost:5173/

## 📁 Estructura del proyecto
```
src/
├── components/    # Componentes reutilizables (tablero, piezas, etc.)
├── pages/         # Páginas principales (Login, Juego, etc.)
├── styles/        # Archivos CSS
├── App.jsx        # Componente principal
└── main.jsx       # Punto de entrada
```

## 👥 Equipo

- **Frontend:** Jeremías Pluas, Persona 2, Persona 3, Persona 4
- **Backend:** Persona 5, Persona 6
- **Infraestructura:** Fernando Reguera, Persona 8